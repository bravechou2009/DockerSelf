<?php
$g_hostname = '15.114.116.166:3306';
$g_db_type = 'mysql';
$g_database_name = 'bugtracker';
$g_db_username = 'mantisbt';
$g_db_password = 'mantisbt';
