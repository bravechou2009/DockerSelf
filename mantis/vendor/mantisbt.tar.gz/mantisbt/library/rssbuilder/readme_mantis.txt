Description of RSSbuilder import into mantis.

See ../readme.libs for summary of all libraries

Removed:

Added:
	readme_mantis.txt - this file ;-)
	index.html - prevent directory browsing on misconfigured servers

Changes:
	none

